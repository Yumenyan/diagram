// =====================================================================
//  Diagram Simulator 用 路線データ書き出しスクリプト — MTR3 + NTE 用
//  この列車に乗ると、走る経路の駅間距離・制限速度・低速区間・加速度を
//  .minecraft/mtrdia/路線名.csv に書き出します（乗るたびに1回）。
//
//  自分の列車のスクリプトに組み込むときは、mtrdia_core.js と このファイルを
//  script_files に追加せず、mtrdia_core.js だけ追加して、render の中で
//      MTRDIA.nte(ctx, state, train);
//  を呼んでください（このファイルの create/render と重ならないように）。
// =====================================================================
MTRDIA.nte = function (ctx, state, train) {
    if (state.mtrdiaDone) return;
    var riding = false;
    try { riding = train.isClientPlayerRiding(); } catch (e) { riding = false; }
    if (!riding) return;
    state.mtrdiaDone = true;
    var say = function (m) { print(m); try { MinecraftClient.displayMessage(m, false); } catch (e) { } };
    try {
        // 線路（車庫からの距離と制限速度）
        var path = train.path(), rails = [], x = 0, i;
        for (i = 0; i < path.size(); i++) {
            var rail = path.get(i).rail, len = Number(rail.getLength()), rt = rail.railType;
            rails.push({ s: x, e: x + len, v: Number(rt.speedLimit), plat: !rt.canAccelerate });
            x += len;
        }
        // 停車するホーム
        var pl = train.getAllPlatforms(), stops = [];
        for (i = 0; i < pl.size(); i++) {
            var p = pl.get(i);
            stops.push({
                name: p.station ? MTRDIA.str(p.station.name) : (p.platform ? MTRDIA.str(p.platform.name) : '?'),
                route: p.route ? MTRDIA.str(p.route.name) : '',
                color: p.route ? p.route.color : 0,
                dist: Number(p.distance)
            });
        }
        // 加速度 m/tick² → km/h/s
        var acc = Number(train.accelerationConstant()) * 400 * 3.6;
        var res = MTRDIA.build(stops, rails, acc);
        var Files = java.nio.file.Files, Paths = java.nio.file.Paths;
        var dir = Paths.get('mtrdia');
        Files.createDirectories(dir);
        for (i = 0; i < res.length; i++) {
            Files.write(dir.resolve(res[i].file), new java.lang.String(res[i].text).getBytes('UTF-8'));
        }
        MTRDIA.report(res, '.minecraft/mtrdia/', say);
    } catch (e) {
        say('[Diagram Simulator] 書き出しに失敗しました: ' + e);
    }
};

function create(ctx, state, train) { }
function render(ctx, state, train) { MTRDIA.nte(ctx, state, train); }
function dispose(ctx, state, train) { }
