// =====================================================================
//  Diagram Simulator 用 路線データ書き出しスクリプト — MTR4 + Joban Client Mod 用
//  この列車に乗ると、走る経路の駅間距離・制限速度・低速区間・加速度を
//  .minecraft/data/mtrscripting/mtrdia/路線名.csv に書き出します（乗るたびに1回）。
//
//  自分の列車のスクリプトに組み込むときは、mtrdia_core.js だけ追加して、render の中で
//      MTRDIA.jcm(ctx, state, vehicle);
//  を呼んでください（このファイルの create/render と重ならないように）。
// =====================================================================
MTRDIA.jcm = function (ctx, state, vehicle) {
    if (state.mtrdiaDone) return;
    var riding = false;
    try { riding = vehicle.isClientPlayerRiding(); } catch (e) { riding = false; }
    if (!riding) { state.mtrdiaWait = 0; return; }
    var say = function (m) { print(m); try { MinecraftClient.displayMessage(m, false); } catch (e) { } };
    // 停車駅の情報（距離つき）を全部そろえてから書き出す
    try { ctx.setDataFetchMode('ALL'); } catch (e) { }
    var full = false;
    try { full = vehicle.isStopsDataFullyFetched(); } catch (e) { full = true; }
    var stopsJ = vehicle.getStops(), i, ok = full && stopsJ.size() > 1;
    for (i = 0; ok && i < stopsJ.size(); i++) if (!(Number(stopsJ.get(i).distance) >= 0)) ok = false;
    if (!ok) {
        state.mtrdiaWait = (state.mtrdiaWait || 0) + 1;
        if (state.mtrdiaWait === 200) say('[Diagram Simulator] 停車駅の情報を待っています…');
        return;
    }
    state.mtrdiaDone = true;
    try {
        var path = vehicle.getPathData(), rails = [];
        for (i = 0; i < path.size(); i++) {
            var pd = path.get(i);
            rails.push({ s: Number(pd.getStartDistance()), e: Number(pd.getEndDistance()), v: Number(pd.getSpeedLimitKilometersPerHour()), plat: Number(pd.getDwellTime()) > 0 });
        }
        var stops = [];
        for (i = 0; i < stopsJ.size(); i++) {
            var st = stopsJ.get(i), rt = st.route;
            stops.push({
                name: MTRDIA.str(st.name),
                route: rt ? MTRDIA.str(rt.getName()) : '',
                color: rt ? rt.getColor() : 0,
                dist: Number(st.distance)
            });
        }
        // MTR4 の加速度は m/ms²（初期値 1/250000 = 14.4km/h/s）
        var a = Number(vehicle.getServiceAcceleration()), acc = a < 0.001 ? a * 3.6e6 : a * 400 * 3.6;
        var res = MTRDIA.build(stops, rails, acc);
        for (i = 0; i < res.length; i++) Files.saveData(res[i].text, 'mtrdia', res[i].file);
        MTRDIA.report(res, '.minecraft/data/mtrscripting/mtrdia/', say);
    } catch (e) {
        say('[Diagram Simulator] 書き出しに失敗しました: ' + e);
    }
};

function create(ctx, state, vehicle) { try { ctx.setDataFetchMode('ALL'); } catch (e) { } }
function render(ctx, state, vehicle) { MTRDIA.jcm(ctx, state, vehicle); }
function dispose(ctx, state, vehicle) { }
