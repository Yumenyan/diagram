// =====================================================================
//  Diagram Simulator 用 路線データ書き出しスクリプト（共通部分）
//  列車の走る経路から、駅間距離・線路の制限速度・低速区間・加速度を調べて
//  Diagram Simulator で読み込める CSV（#mtrdia 形式）に書き出します。
//  Rhino で動くよう ES5 で書いています。
// =====================================================================
var MTRDIA = (function () {
    var VERSION = '1.0.0';

    function str(x) { return x === null || x === undefined ? '' : String(x); }
    // CSV はカンマ区切りなので、名前の中のカンマと改行は置き換える
    function cell(x) { return str(x).replace(/[\r\n]+/g, ' ').replace(/,/g, '、'); }
    // 路線名の「||」より後（行先・方向）は路線名に含めない
    function lineName(n) { n = str(n); var i = n.indexOf('||'); return i >= 0 ? n.substring(0, i) : n; }
    function fileName(n) { n = str(n).replace(/\|/g, '_').replace(/[\\\/:*?"<>]/g, '_').replace(/\s+/g, '_'); return (n || 'route').substring(0, 60) + '.csv'; }
    function hex(c) { c = Number(c); if (isNaN(c)) return ''; c = (c & 0xFFFFFF).toString(16); while (c.length < 6) c = '0' + c; return '#' + c; }
    function r1(x) { return Math.round(x * 10) / 10; }

    // stops: [{ name, route, color, dist }]（経路の順）
    // rails: [{ s, e, v, plat }]（車庫からの距離 s〜e、制限速度 km/h、ホームや留置線なら plat=true）
    // acc: 加速度 km/h/s
    function build(stops, rails, acc) {
        var groups = [], cur = null, i, j;
        for (i = 0; i < stops.length; i++) {
            var st = stops[i];
            if (!cur || cur.route !== st.route) { cur = { route: st.route, color: st.color, stops: [] }; groups.push(cur); }
            var prev = cur.stops[cur.stops.length - 1];
            if (prev && prev.name === st.name && Math.abs(prev.dist - st.dist) < 1) continue; // 乗り換えで二重になった停車
            cur.stops.push(st);
        }
        var out = [], sigs = {}, names = {};
        for (i = 0; i < groups.length; i++) {
            var g = groups[i];
            if (g.stops.length < 2) continue;
            var nm = [], k;
            for (k = 0; k < g.stops.length; k++) nm.push(g.stops[k].name);
            var sig = nm.join('>'), rev = nm.slice().reverse().join('>');
            if (sigs[sig] || sigs[rev]) continue; // 同じ路線の往復（上り）や繰り返しは1回だけ
            sigs[sig] = true;
            var ln = lineName(g.route) || ('route' + (out.length + 1));
            var lines = ['#mtrdia,2,' + cell(ln) + ',' + r1(acc) + ',' + hex(g.color) + ',' + VERSION];
            for (k = 0; k < g.stops.length; k++) {
                var a = g.stops[k].dist, b = k + 1 < g.stops.length ? g.stops[k + 1].dist : a;
                var seg = [], vmax = 0;
                for (j = 0; j < rails.length; j++) {
                    var rr = rails[j];
                    if (rr.e <= a + 0.01 || rr.s >= b - 0.01 || rr.plat || !(rr.v > 0)) continue;
                    seg.push(rr); if (rr.v > vmax) vmax = rr.v;
                }
                if (!vmax) vmax = k > 0 && g.lastV ? g.lastV : 80;
                g.lastV = vmax;
                var d = Math.max(0, b - a);
                lines.push('S,' + cell(g.stops[k].name) + ',' + r1(d) + ',' + vmax);
                // 制限速度が下がる区間（隣り合う同じ速度はまとめる）
                var zs = [];
                for (j = 0; j < seg.length; j++) {
                    var q = seg[j];
                    if (q.v >= vmax) continue;
                    var s0 = Math.max(q.s, a) - a, s1 = Math.min(q.e, b) - a, z = zs[zs.length - 1];
                    if (z && z.v === q.v && Math.abs(z.at + z.len - s0) < 0.5) z.len = s1 - z.at;
                    else zs.push({ at: s0, len: s1 - s0, v: q.v });
                }
                for (j = 0; j < zs.length; j++) if (zs[j].len >= 5) lines.push('Z,' + (k + 1) + ',' + r1(zs[j].at) + ',' + r1(zs[j].len) + ',' + zs[j].v);
            }
            var fn = fileName(ln); if (names[fn]) fn = fn.replace(/\.csv$/, '_' + (out.length + 1) + '.csv'); names[fn] = true;
            out.push({ name: ln, file: fn, text: lines.join('\n') + '\n', count: g.stops.length });
        }
        return out;
    }

    function report(results, where, say) {
        if (!results.length) { say('[Diagram Simulator] 書き出せる路線がありませんでした（駅が2つ以上ある路線が必要です）'); return; }
        var names = [];
        for (var i = 0; i < results.length; i++) names.push(results[i].name + '（' + results[i].count + '駅）');
        say('[Diagram Simulator] ' + names.join('、') + ' を ' + where + ' に書き出しました');
    }

    return { VERSION: VERSION, build: build, report: report, str: str };
})();
